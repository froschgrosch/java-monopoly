package model;
public class Spiel
{
    Spieler spieler[] = new Spieler[4];
    Feld felder[]; // 40 Felder
    public Spiel(int anzahlFelder)
    {
        for (int i = 0; i < 4; i++) {
            spieler[i] = null;
        }
        felder = new Feld[anzahlFelder];
    }
}
