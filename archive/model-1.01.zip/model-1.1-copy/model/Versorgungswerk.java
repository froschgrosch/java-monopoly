package model;

public class Versorgungswerk extends Feld
{
    int preise[]; // Größe 3
    /* 0: Kaufpreis
     * 1: Hypothekenwert
     * 2: Hypothek auflösen */
    String name;
    Spieler besitzer;
    public Versorgungswerk(String n){
        name = n;
    }

    int mieteBerechnen(int gewuerfelt){
        int miete = 0;
        if(besitzer.getAnzahlVWs() == 1) {
            miete = gewuerfelt * 4;
        }
        else if(besitzer.getAnzahlVWs() == 2){
            miete = gewuerfelt * 10;
        }
        return miete;
    }
}