package model;
public class Spieler
{
    int geldstand;

    int anzahlHaeuser[];
    private int anzahlBahnhoefe = 0;
    private int anzahlVWs = 0; // Versorgungswerke
    int feld = 0; // aktuelles Feld
    boolean imGefaengnis = false;

    String name;
    int figur;
    int farbe[]; // {rot, grün, blau}

    public Spieler(String n, int gruppen, int startguthaben, int fi, int[] fa)
    {
        geldstand = startguthaben;
        anzahlHaeuser = new int[gruppen];
        for (int i = 0; i < gruppen; i++) {
            anzahlHaeuser[i] = 0;
        }
        name = n;
        figur = fi;
        farbe = fa;
    }

    int getAnzahlBahnhoefe(){
        return anzahlBahnhoefe;   
    }

    int getAnzahlVWs(){
        return anzahlVWs;
    }

    boolean genugGeld(int preis){
        return preis <= geldstand;
    }

    void geldAbziehen(int menge){ // vorher genugGeld() prüfen!
        geldstand = geldstand - menge;
    }

    void geldHinzufuegen(int menge){
        geldstand = geldstand + menge;
    }

    boolean istPasch(int zahl1, int zahl2){
        return zahl1 == zahl2;
    }

    int wuerfeln(){
        return (int)(Math.random()* 6)+1;
    }

    /* int[] wuerfelnGanz(){
    int ergebnis[] = new int[3];
    ergebnis[0] = (int)(Math.random()* 6)+1;
    ergebnis[1] = (int)(Math.random()* 6)+1;
    ergebnis[2] = 0;
    if (ergebnis[0] == ergebnis[1]) {
    ergebnis[2] = 1;
    }
    return ergebnis; 
    } // */
}
