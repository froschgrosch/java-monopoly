package model;
public class Bahnhof extends Feld
{
    int preise[]; // Größe 4
    /* 0: Kaufpreis
     * 1: Miete
     * 2: Hypothekenwert
     * 3: Auflösen der Hypothek */
    Spieler besitzer = null;
    boolean hypothek = false;

    public Bahnhof()
    {
    }

    int ermittleMiete(int gewuerfelt) {
        int miete = 0;
        if (besitzer != null && !hypothek) {
            miete = preise[1] * (2 ^ (besitzer.getAnzahlBahnhoefe() - 1));
        }
        return miete;
    }

    int kaufpreisAusgeben(){
        return preise[0];
    }
}
