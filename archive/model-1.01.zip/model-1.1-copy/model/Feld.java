package model;
class Feld
 {
    int mieteBerechnen(int gewuerfelt){
        return 0;
    }

    int kaufpreisAusgeben(){
        return 0;
    }
    
    void kaufen(Spieler s){} // nur aufrufen nach s.genugGeld()
    
    void hypothekSetzen(Spieler s){}
    
    void hypothekAuflosesen(Spieler s){} // nur aufrufen nach s.genugGeld()
}
