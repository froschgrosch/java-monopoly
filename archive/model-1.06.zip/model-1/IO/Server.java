package IO;

import java.net.*;
import java.io.*;

public class Server
{
    ServerSocket server;
    Socket client = null;
    PrintWriter out;
    BufferedReader in;
    public Server(int port)
    {
        try{
            server = new ServerSocket(port);
        } catch(Exception e) {e.printStackTrace();}
    }

    public void serverWrite(String input) {
        out.println(input);
    }

    public void waitForConnection(){ // neuen Thread starten
        try{
            client = server.accept();
            out = new PrintWriter(client.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        } catch(Exception e) {e.printStackTrace();}
    }

    public String serverRead(){
        String output = "";
        if (client != null) {
            try{
                output = in.readLine();
            } catch(Exception e) {e.printStackTrace();}
        }
        return output;   
    }
}
