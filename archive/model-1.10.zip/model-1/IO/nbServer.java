package IO;
import java.nio.channels.*;
import java.nio.*;
import java.net.*;
public class nbServer extends nbClient
{
    ServerSocketChannel ssc;
    SocketChannel sc = null;
    public nbServer(int port)
    {
        try{
            ssc = ServerSocketChannel.open();
            ssc.socket().bind(new InetSocketAddress(port));            
            ssc.configureBlocking(false);
        } catch(Exception e){e.printStackTrace();}
    }

    public void waitForConnection(){
        try{
            while (sc == null){
                sc = ssc.accept();
            }
            System.out.println("connected");
        } catch(Exception e){e.printStackTrace();}
    }

    public void close(){
        try{
            ssc.close();
            sc = null;
        }catch (Exception e){e.printStackTrace();}
    }
}
