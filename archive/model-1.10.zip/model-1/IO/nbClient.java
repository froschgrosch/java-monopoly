package IO;
import java.nio.channels.*;
import java.nio.*;
import java.net.*;
public class nbClient
{
    SocketChannel sc;
    public nbClient()
    {
        try{
            sc = SocketChannel.open();
            sc.configureBlocking(false);
        }catch (Exception e){e.printStackTrace();}
    }

    public void connect(String ip, int port){
        try{
            sc.connect(new InetSocketAddress(ip, port));
            while(!sc.finishConnect()){
                // warten
            }
        }catch (Exception e){e.printStackTrace();}
    }

    public void close(){
        try{
            sc.close();
        }catch (Exception e){e.printStackTrace();}
    }

    public int write(byte data){
        int output = -10;
        ByteBuffer b = ByteBuffer.allocate(64);
        b.clear();
        b.put(data);
        b.flip();
        try{
            while(b.hasRemaining()) {
                output = sc.write(b);
            }
        }catch (Exception e){e.printStackTrace();}
        return output;
    }

    public int read(){
        int output = 0;
        ByteBuffer b = ByteBuffer.allocate(64);
        try{
            output = sc.read(b);
        }catch (Exception e){e.printStackTrace();}
        return output;
    }
}
