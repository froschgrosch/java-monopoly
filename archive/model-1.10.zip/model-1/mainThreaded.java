import IO.*;
import model.*;
public class mainThreaded extends Thread{
    model_main Spiel = new model_main(200,1500);
    MultiServer s = new MultiServer(12345,4);
    int[] black = {0,0,0};

    String[] oldMessage = new String[4];
    String[] newMessage = new String[4];

    public mainThreaded(){}

    public Spieler getSpielerAmZug(){
        return Spiel.getSpieler()[Spiel.getAktuellerSpieler()];
    }

    public void run(){
        s.waitForConnection();
        System.out.println("connected");
        while(true){
            for(int i = 0; i < 4; i++){
                newMessage[i] = s.read(i);
                if (newMessage[i] != oldMessage[i]){
                    System.out.println(newMessage[i]);
                    newMessage[i] = oldMessage[i];
                }
            }
        }
    }

    public void handleNetwork(String s){
    }

    public void close(){
        stop();
        s.closeAll();
    }
}