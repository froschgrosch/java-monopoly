import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.awt.*;

import model.*;

public class View3 extends JFrame {
    JLabel ausgabe;
    public View3(ActionListener listener, model_main main) {
        Feld[] felder = main.getFelder();
        Gruppe[] gruppen = main.getGruppen();
        Spieler[] spieler = main.getSpieler();

        setTitle("MONOPOLY Reuchlin-Edition");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new BorderLayout());

        //Haupt-Panel
        JPanel haupt = new JPanel();
        JPanel h1 = new JPanel();
        JPanel h2 = new JPanel();
        JPanel h3 = new JPanel();
        haupt.setLayout(new GridLayout(3,1));

        JLabel name = new JLabel("Monopoly");
        JButton b1 = new JButton("Wuerfeln");
        JButton b2 = new JButton("Naechster");
        ausgabe = new JLabel("---");

        b1.addActionListener(listener);
        b2.addActionListener(listener);

        h1.add(name);
        h2.add(b1);
        h2.add(b2);
        h3.add(ausgabe);

        haupt.add(h1);
        haupt.add(h2);
        haupt.add(h3);

        //Unten-Panel
        JPanel unten = new JPanel();
        //unten.setLayout(new GridLayout(10,10));
        JLabel[] reiheunten = new JLabel[11];
        for (int i = 0; i < reiheunten.length; i++) {
            reiheunten[i] = new JLabel(felder[10-i].getName());
            unten.add(reiheunten[i]);
        }

        //Links-Panel
        JPanel links = new JPanel();
        links.setLayout(new GridLayout(10,1));
        JLabel[] reihelinks = new JLabel[9];
        for (int i = 0; i < reihelinks.length; i++) {
            reihelinks[i] = new JLabel(felder[19-i].getName());
            links.add(reihelinks[i]);
        }

        //Oben-Panel
        JPanel oben = new JPanel();
        JLabel[] reiheoben = new JLabel[11];
        for (int i = 0; i < reiheoben.length; i++) {
            reiheoben[i] = new JLabel(felder[20+i].getName());
            oben.add(reiheoben[i]);
        }

        //Rechts-Panel
        JPanel rechts = new JPanel();
        rechts.setLayout(new GridLayout(10,1));
        JLabel[] reiherechts = new JLabel[9];
        for (int i = 0; i < reiherechts.length; i++) {
            reiherechts[i] = new JLabel(felder[31+i].getName());
            rechts.add(reiherechts[i]);
        }

        //Top-Level
        add(haupt, BorderLayout.CENTER);
        add(oben, BorderLayout.NORTH);
        add(links, BorderLayout.WEST);
        add(rechts, BorderLayout.EAST);
        add(unten, BorderLayout.SOUTH);
        pack();
        setVisible(true);
    }

    public void showMessage(String text) {
        ausgabe.setText(text);
    }
}
