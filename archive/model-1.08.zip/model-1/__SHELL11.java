

public class __SHELL11 extends bluej.runtime.Shell {
public static void run() throws Throwable {
final bluej.runtime.BJMap __bluej_runtime_scope = getScope("F:\\Informatik\\Programme BlueJ\\Monopoly\\model-1");
final test test1 = (test)__bluej_runtime_scope.get("test1");


test1.m1.s.write(0,"test");

}}
