import IO.*;

public class test{
    mainThreaded m1 = new mainThreaded();
    public test(){
        m1.start();
    }
}