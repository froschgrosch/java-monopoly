package IO;
public class ThreadedClient extends Thread{
    Client c = new Client();
    String oldMessage = "";
    String newMessage;
    int number;
    public ThreadedClient(int n){
        number = n;
        start();
    }

    public void run(){

        c.connect("localhost",12345);
        while(true){
            newMessage = c.read();
            if(newMessage != oldMessage){
                System.out.println("Client "+number+" reads:"+newMessage);
                oldMessage = newMessage;
            }
        }
    }

    public void closeConnection(){
        c.close();
    }

    public void write(String message){
        System.out.println("Client writes: "+message);
        c.write(message);
    }    
}
