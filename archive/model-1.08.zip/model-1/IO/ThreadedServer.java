package IO;
public class ThreadedServer extends Thread {

    Server s;
    String oldMessage = "";
    String newMessage;
    boolean run = true;
    public ThreadedServer(int port){
        s = new Server(port);
    }

    public void run() {
        s.waitForConnection();
        System.out.println("Connection established");
        run = true;
        while(run){
            newMessage = s.read();
            if(newMessage != oldMessage){
                System.out.println("Server reads:"+newMessage);
                 oldMessage = newMessage;
            }
        }
    }

    public void closeConnection(){
        s.close();
        run = false;
    }

    public void write(String message){
        System.out.println("Server writes: "+message);
        s.write(message);
    }
}

