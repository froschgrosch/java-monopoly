package model;
public class Bahnhof extends Feld
{
    int preis;
    Spieler besitzer = null;
    
    public Bahnhof(int p)
    {
    preis = p;
    }

    int ermittleMiete(int gewuerfelt) {
        int miete = 0;
        if (besitzer != null) {
          miete = preis * (2 ^ (besitzer.getAnzahlBahnhoefe() - 1));
        }
        return miete;
    }

}
