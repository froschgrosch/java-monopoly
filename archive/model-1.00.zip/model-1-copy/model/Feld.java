package model;
abstract class Feld
{
int mieteBerechnen(int gewuerfelt){
 return 0;
}
}
