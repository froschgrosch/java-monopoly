package model;
public class Spieler
{
    int geldstand;
    int anzahlHaeuser[];
    private int anzahlBahnhoefe = 0;
    public Spieler(int gruppen)
    {
        anzahlHaeuser = new int[gruppen];
        for (int i = 0; i < gruppen; i++) {
            anzahlHaeuser[i] = 0;
        }
    }
    
    int getAnzahlBahnhoefe(){
     return anzahlBahnhoefe;   
    }
}
