package model;
public class Strasse extends Feld
{
    int[] preise = new int[10]; /*
    0: Kaufpreis
    1: unbebaute Miete
    2: Miete 1 Haus
    3: Miete 2 Häuser
    4: Miete 3 Häuser
    5: Miete 4 Häuser
    6: Miete Hotel (als 5 Häuser speichern!)
    7: Kaufpreis Haus
    8: Hypothekenwert
    9: Auflösekosten der Hypothek */

    int gebauteHaeuser = 0;

    String name;
    int gruppe;
    boolean hypothek = false;
    Spieler besitzer = null;

    public Strasse(String n, int g)
    {
        name = n;
        gruppe = g;
    }

    int mieteBerechnen(int gewuerfelt){
        int miete = 0;
        if (!hypothek && besitzer != null){
            miete = preise[1+gebauteHaeuser];
        }
        return miete;
    }
}
