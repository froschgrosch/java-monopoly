package model;
public class Feld
{
    int miete;
    int karte;
    /* 0: normales Feld
     * 1: Ereigniskarte ziehen
     * 2: Gemeinschaftskarte ziehen
     * 3: frei parken
     * 4: gehe ins Gefängnis
     */
    public Feld(int[] m){
        miete = m[0];
    }

    public void setKarte(int k){
        karte = k;
    }
    
    public int getKarte(){
        return karte;
    }

    public int mieteBerechnen(int gewuerfelt){
        return miete;
    }

    public int kaufpreisAusgeben(){
        return 0;
    }

    public Spieler hausKaufen(Spieler s){return s;}

    public Spieler kaufen(Spieler s){return s;} // nur aufrufen nach s.genugGeld()
    public Spieler hypothekSetzen(Spieler s){return s;}

    public Spieler hypothekAuflosesen(Spieler s){return s;} // nur aufrufen nach s.genugGeld()
}
