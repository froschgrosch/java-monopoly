package model;
import IO.Reader;

public class model_main
{
    Reader r = new Reader();
    Spieler[] spieler = new Spieler[4];
    int spielerRegistriert = 0;
    Feld[] felder = new Feld[40];
    int gruppen = 8;
    int aktuellerSpieler = 0;
    int losBetrag;
    int startGuthaben;
    Karte ek[];
    Karte gk[];
    int geldInderMitte = 0;

    public model_main(int lb, int sg)
    {
        losBetrag = lb;
        
        gk = kartenEinlesen("data\\Gemeinschaft.txt");
        /*
        String[] datei = r.read("data\\Gemeinschaft.txt");
        for (int i = 0; i < datei.length; i++){
        System.out.println(datei[i]);
        } // */
    }
    
    Spieler spielerErstellen(String n, int[] farbe, int figur){
       spieler[spielerRegistriert] = new Spieler(spielerRegistriert, n, gruppen, startGuthaben, losBetrag, farbe, figur);
       spielerRegistriert++;
       return spieler[spielerRegistriert - 1];
    }

    int[] mieteZahlen(int gewuerfelt){
       int[] ergebnis = new int[3];
       /* 0 : Miete
        * 1 : zahlender Spieler
        * 2 : Besitzer */
       ergebnis[0] = felder[spieler[aktuellerSpieler].getFeld()].mieteBerechnen(gewuerfelt);
       ergebnis[1] = aktuellerSpieler;
       ergebnis[2] = felder[
    }
    
    int getGeldInderMitte(){
        return geldInderMitte;
    }

    Spieler[] getSpieler(){ // 0 bis 3
        return spieler;
    }

    int getFeldSpieler(int nummer){
        return spieler[nummer].getFeld();
    }

    int getKontostandSpieler(int nummer){
        return spieler[nummer].getKontostand();
    }

    int getAktuellerSpieler(){
        return aktuellerSpieler;
    }

    Feld getFeld(int nummer){ 
        Feld output = null;
        if (nummer < felder.length){
            output = felder[nummer];
        }
        return output;
    }

    int[] wuerfeln(){ // Wenn ergebnis[2] == 1 muss der Controller nochmal würfeln
        int[] ergebnis = spieler[aktuellerSpieler].ziehen(felder);
        if (ergebnis[2] == 4){
            spieler[aktuellerSpieler].setKarte(null);
            // Karte wieder in Umlauf bringen
        }
        return ergebnis;
    }

    int zugBeenden(){
        if (aktuellerSpieler == spieler.length - 1){ // spieler 3 --> spieler 0
            aktuellerSpieler = 0;
        } else {
            aktuellerSpieler++;
        }
        return aktuellerSpieler;   
    }

    public Karte karteZiehen(Karte[] kartenArray){
        return kartenArray[(int)(Math.random()*(kartenArray.length-1))];

        //  handleKarte(k);
    }

    private void handleKarte(Karte k){
        int[] p = k.getParams();
        switch(k.getType()){
            case 0: // Spieler erhält Geld
            spieler[aktuellerSpieler].einzahlen(p[0]);
            case 1: // Alle Spieler zahlen akt. Spieler 
            int tempindex = 0;
            for (int i = 0; i < spieler.length; i++){
                spieler[i].abheben(p[0]);
                tempindex++;
            }
            spieler[aktuellerSpieler].einzahlen(p[0]*tempindex);
            break;
            case 2: // auf Feld springen
            spieler[aktuellerSpieler].springen(p[0]);
            break;
            case 3: // renovieren

            break;
            case 4: // Gefaengniskarte
            spieler[aktuellerSpieler].setKarte(k);
            break;
            case 5:
            spieler[aktuellerSpieler].gehen(p[0]);
            break;
            default:
            // tu nichts
            break;
        }
    }

    private Karte[] kartenEinlesen(String dateiname){
        String[] t = r.read(dateiname);
        Karte[] k = new Karte[t.length-1];
        for (int i = 0; i < t.length-1; i++){
            if (t[i] != null){
                System.out.println(i);
                int split1 = Integer.valueOf(t[i].split(":")[0]); // Typ
                System.out.println(split1);
                int split2 = Integer.valueOf(t[i].split(":")[1]); // Parameter 1
                System.out.println(split2);
                int split3 = Integer.valueOf(t[i].split(":")[2]); // Parameter 2
                System.out.println(split3);
                String text = t[i].split(":")[3]; // Text
                System.out.println(text);
                switch(split1){
                    case 0: // Spieler erhält Geld
                    k[i] = new Karte(0,split2,text);
                    break;
                    case 1: // Alle Spieler zahlen akt. Spieler 
                    k[i] = new Karte(1,split2,text);
                    break;
                    case 2:
                    k[i] = new Karte(2,split2,text);
                    break;
                    case 3:
                    k[i] = new Karte(3,split2,split3,text);
                    break;
                    case 4: // Gefaengniskarte
                    k[i] = new Karte(4,text);
                    break;
                    case 5:
                    k[i] = new Karte(5,split2,text);
                    break;
                    default:
                    // tu nichts
                    break;
                }
            }
        }
        return k;
    }
}
