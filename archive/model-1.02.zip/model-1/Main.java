import model.*;
public class Main
{
    
    int gruppen = 8;
    int felder = 40;
    Spieler s1;
    Feld st1;
    int[] preise = {1,2,3,4,5,6,7,8,9,10};

    public Main()
    {
    s1 = new Spieler(gruppen, 1000);
    st1 = new Strasse("Straße1",0, preise);
    s1 = st1.kaufen(s1);
    }
     
/*
    VOXtranslator vt = new VOXtranslator();
    Player p = new Player();
    String numbers_path = "vox-files\\numbers\\";
    long delay; // Etwa 0.2
    public Main(double _delay){
        delay = (long)_delay;
    }

    public void sayNumber(int number) {
        String[] s = vt.toStringArr(number);
        for (int i = 0; i < s.length; i++){
            p.play(numbers_path+s[i],delay);
        }
    }
*/
}