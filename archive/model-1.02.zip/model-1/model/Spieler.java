package model;
public class Spieler
{
    int geldstand;

    int anzahlHaeuser[]; // index ist gruppe;
    private int anzahlBahnhoefe = 0;
    private int anzahlVWs = 0; // Versorgungswerke
    int feld = 0; // aktuelles Feld
    boolean imGefaengnis = false;
/*
    String name;
    int figur;
    int farbe[]; // {rot, grün, blau} */
    public Spieler(/*String n, */int gruppen, int startguthaben/*, int fi, int[] fa*/)
    {
        geldstand = startguthaben;
        anzahlHaeuser = new int[gruppen];
        for (int i = 0; i < gruppen; i++) {
            anzahlHaeuser[i] = 0;
        } 
        /*
        name = n;
        figur = fi;
        farbe = fa; // */
    }

    public int getAnzahlHaeuser(int gruppe){
        return anzahlHaeuser[gruppe];
    }

    public int getAnzahlBahnhoefe(){
        return anzahlBahnhoefe;   
    }

    public int getAnzahlVWs(){
        return anzahlVWs;
    }

    public boolean genugGeld(int preis){
        return preis <= geldstand;
    }

    public void geldAbziehen(int menge){ // vorher genugGeld() prüfen!
        geldstand = geldstand - menge;
    }

    public void geldHinzufuegen(int menge){
        geldstand = geldstand + menge;
    }

    public void strasseHinzufuegen(int gruppe){
        anzahlHaeuser[gruppe]++;
    }

    public void VWhinzufuegen(){
        anzahlVWs++;
    }

    public void bahnhofHinzufuegen(){
        anzahlBahnhoefe++;
    }

    public boolean istPasch(int zahl1, int zahl2){
        return zahl1 == zahl2;
    }

    public int wuerfeln(){
        return (int)(Math.random()* 6)+1;
    }

    /* int[] wuerfelnGanz(){
    int ergebnis[] = new int[3];
    ergebnis[0] = (int)(Math.random()* 6)+1;
    ergebnis[1] = (int)(Math.random()* 6)+1;
    ergebnis[2] = 0;
    if (ergebnis[0] == ergebnis[1]) {
    ergebnis[2] = 1;
    }
    return ergebnis; 
    } // */
}
