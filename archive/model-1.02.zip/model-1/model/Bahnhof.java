package model;
public class Bahnhof extends Feld
{
    private int preise[] = new int[4]; // Größe 4
    /* 0: Kaufpreis
     * 1: Miete
     * 2: Hypothekenwert
     * 3: Auflösen der Hypothek */
    String name;
    Spieler besitzer = null;
    boolean hypothek = false;

    public Bahnhof(String n)
    {
        name = n;
    }

    public int ermittleMiete(int gewuerfelt) {
        int miete = 0;
        if (besitzer != null && !hypothek) {
            miete = preise[1] * (2 ^ (besitzer.getAnzahlBahnhoefe() - 1));
        }
        return miete;
    }

    public int kaufpreisAusgeben(){
        return preise[0];
    }

    public Spieler kaufen(Spieler s){ // nur nach s.genugGeld(preise[0]) aufrufen!
        if (besitzer == null){
            s.geldAbziehen(preise[0]);
            s.bahnhofHinzufuegen();
            besitzer = s;
        }
        return s;
    }

    public Spieler hypothekSetzen(){
        if (besitzer != null){
            hypothek = true;
            besitzer.geldHinzufuegen(preise[2]);
        }
        return besitzer;
    }

    Spieler hypothekAufloesen(){ // nur nach besitzer.genugGeld() aufrufen!
        if (besitzer != null){
            hypothek = false;
            besitzer.geldAbziehen(preise[3]);
        }
        return besitzer;
    }

    public void saveLaden(boolean hypo, Spieler b){
        hypothek = hypo;
        besitzer = b;
    }
}
