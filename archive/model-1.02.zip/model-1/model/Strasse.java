package model;
public class Strasse extends Feld
{
    int[] preise = new int[10]; // Größe 10
    /* 0: Kaufpreis
     * 1: unbebaute Miete
     * 2: Miete 1 Haus
     * 3: Miete 2 Häuser
     * 4: Miete 3 Häuser
     * 5: Miete 4 Häuser
     * 6: Miete Hotel (als 5 Häuser speichern!)
     * 7: Kaufpreis Haus
     * 8: Hypothekenwert
     * 9: Auflösen der Hypothek */

    String name;
    int gruppe;
    int haeuserProGruppe;
    
    int gebauteHaeuser = 0;
    boolean hypothek = false;
    Spieler besitzer = null;

    public Strasse(String n, int g, int hpg, int[] p)
    {
        name = n;
        gruppe = g;
        haeuserProGruppe = hpg;
        preise = p;
    }

    public int mieteBerechnen(int gewuerfelt){
        int miete = 0;
        if (!hypothek && besitzer != null){
            miete = preise[1+gebauteHaeuser];
        }
        return miete;
    }

    public int kaufpreisAusgeben(){
        return preise[0];
    }

    public Spieler kaufen(Spieler s){ // nur nach s.genugGeld(preise[0]) aufrufen!
        if (besitzer == null){
            s.geldAbziehen(preise[0]);
            s.strasseHinzufuegen(gruppe);
            besitzer = s;
        }
        return s;
    }

    public Spieler hypothekSetzen(){
        if (besitzer != null){
            hypothek = true;
            besitzer.geldHinzufuegen(preise[8]);
        }
        return besitzer;
    }

    public Spieler hypothekAufloesen(){ // nur nach besitzer.genugGeld(preise[9]) aufrufen!
        if (besitzer != null){
            hypothek = false;
            besitzer.geldAbziehen(preise[9]);
        }
        return besitzer;
    }

    public void saveLaden(boolean hypo, Spieler b, int haeuser){
        gebauteHaeuser = haeuser;
        hypothek = hypo;
        besitzer = b;
    }
}
