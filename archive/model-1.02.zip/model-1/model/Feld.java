package model;
public class Feld
 {
    public int mieteBerechnen(int gewuerfelt){
        return 0;
    }

    public int kaufpreisAusgeben(){
        return 0;
    }
    
    public Spieler hausKaufen(Spieler s){return s;}
    public Spieler kaufen(Spieler s){return s;} // nur aufrufen nach s.genugGeld()
    public Spieler hypothekSetzen(Spieler s){return s;}
    public Spieler hypothekAuflosesen(Spieler s){return s;} // nur aufrufen nach s.genugGeld()
}
