package IO;
public class ThreadedClient extends Thread{
    Client c = new Client();
    String oldMessage = "";
    String newMessage;
    public ThreadedClient(){}

    public void run(){
        c.connect("localhost",12345);
        while(true){
            newMessage = c.read();
            if(newMessage != oldMessage){
                System.out.println("Client reads:"+newMessage);
                oldMessage = newMessage;
            }
        }
    }

    public void closeConnection(){
        c.close();
    }

    public void write(String message){
        System.out.println("Client writes: "+message);
        c.write(message);
    }    
}
