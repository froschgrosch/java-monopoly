package IO;

import java.net.*;
import java.io.*;

public class BroadcastServer
{
    ServerSocket server;
    PrintWriter[] out;
    BufferedReader[] in;
    Socket[] clients;
    int connectedClients = 0;
    int maxClients;
    public BroadcastServer(int port, int c)
    {
        try{
            server = new ServerSocket(port);
            Socket[] clients = new Socket[c];
            out = new PrintWriter[c];
            clients = new Socket[c];
            maxClients = c;
        } catch(Exception e) {e.printStackTrace();}
    }

    public void waitForConnection(){
        try{
            clients[connectedClients] = server.accept();
            out[connectedClients] = new PrintWriter(clients[connectedClients].getOutputStream(), true);
        } catch (Exception e){e.printStackTrace();}
    }

    public void broadcast(String message) {
        for (int i = 0; i < out.length; i++) {
            out[i].println(message);
        }
    }

    public void write(int client, String message){
        out[client].println(message);
    }

    public String read(int client){
        String output = "";
        try{
            output = in[client].readLine();
        } catch(Exception e) {e.printStackTrace();}
        return output;
    }
    
    public void closeAll(){
        try{
            server.close();
        } catch(Exception e){e.printStackTrace();}
        clients = null;
        out = null;
        in = null;
    }
}
