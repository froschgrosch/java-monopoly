import IO.*;

public class test
{
    ThreadedServer s1 = new ThreadedServer(12345);
    ThreadedClient c1 = new ThreadedClient();
    public test()
    {
        s1.start();
        c1.start();
    }

    public void stop(){
        c1.stop();        
        s1.stop();
        c1.closeConnection();
        s1.closeConnection();
    } 

    public void sWrite(String s){
        s1.write(s);
    }

    public void cWrite(String s){
        c1.write(s);
    }

}
