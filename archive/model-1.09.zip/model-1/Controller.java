import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.model_main;

public class Controller implements ActionListener {

    private View3 fenster;
    private model_main model;

    public Controller() {
        model = new model_main(200,1500);
        fenster = new View3(this,model);
    }

    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        if (command.equals("Wuerfeln")) {
            fenster.showMessage("W");
            System.out.println("W");
        } else if (command.equals("Naechster")) {
            fenster.showMessage("N");
            System.out.println("N");            
        }
    }

}