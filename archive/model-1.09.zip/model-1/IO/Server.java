package IO;

import java.net.*;
import java.io.*;

public class Server
{
    boolean connected = false;
    ServerSocket server;
    Socket client = null;
    PrintWriter out;
    BufferedReader in;
    public Server(int port)
    {
        try{
            server = new ServerSocket(port);
        } catch(Exception e) {e.printStackTrace();}
    }

    public void write(String input) {
        out.println(input);
    }

    public void waitForConnection(){ // neuen Thread starten
        try{
            client = server.accept();
            out = new PrintWriter(client.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            connected = true;
            out.println("");
        } catch(Exception e) {e.printStackTrace();}
    }

    public String read(){
        String output = "";
        if (connected) {
            try{
                output = in.readLine();
            } catch(Exception e) {e.printStackTrace();}
        }
        return output;   
    }

    public void close(){
        try{
            server.close();
        } catch(Exception e){e.printStackTrace();}
        client = null;
        out = null;
        in = null;
        connected = false;
    }
}
