package IO;

import java.net.*;
import java.io.*;

public class Client
{
    Socket socket;
    PrintWriter out;
    BufferedReader in;

    public Client(){
    }

    public void connect(String ip, int port){
        try{
            socket = new Socket(ip, port);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out.println("");
        } catch(Exception e) {e.printStackTrace();}
    }

    public void write(String input) {
        out.println(input);
    }

    public String read(){
        String output = "";
        try{
            output = in.readLine();
        } catch(Exception e){e.printStackTrace();}
        return output;
    }

    public void close(){
        try{
            socket.close();
        } catch(Exception e){e.printStackTrace();}
        out = null;
        in = null;
    }

}
