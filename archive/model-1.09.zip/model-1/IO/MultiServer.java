package IO;

import java.net.Socket;
import java.net.ServerSocket;

import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MultiServer
{
    ServerSocket server;
    PrintWriter[] out;
    BufferedReader[] in;
    int connectedClients = 0;
    int maxClients;
    public MultiServer(int port, int c)
    {
        out = new PrintWriter[c];
        in = new BufferedReader[c];
        maxClients = c;
        try{
            server = new ServerSocket(port);
        } catch(Exception e) {e.printStackTrace();}
    }

    public void waitForConnection(){
        try{
            Socket c = server.accept();
            out[connectedClients] = new PrintWriter(c.getOutputStream(), true);
            in[connectedClients] = new BufferedReader(new InputStreamReader(c.getInputStream()));
            in[connectedClients].readLine();
        } catch (Exception e){e.printStackTrace();}
        connectedClients++;
    }

    public void broadcast(String message) {
        for (int i = 0; i < out.length; i++) {
            write(i,message);
        }
    }

    public void write(int client, String message){
        if(out[client] != null) {
            out[client].println(message);
        }
    }

    public String read(int client){
        String output = "";
        if (in[client] != null) {
            try{
                output = in[client].readLine();
            } catch(Exception e) {e.printStackTrace();}
        }
        return output;   
    }

    public void closeAll(){
        out = new PrintWriter[maxClients];
        in = new BufferedReader[maxClients];
        connectedClients = 0;
    }

    public int getConnectedClients(){
        return connectedClients;
    }
}
