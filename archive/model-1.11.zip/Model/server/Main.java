import model.*;
import IO.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Main {
    int port = 12345;

    model_main Spiel;
    SocketHandlerThread[] sockenhaendler = new SocketHandlerThread[4];
    ServerSocket server;

    String newMessage[] = {"","","",""};
    String oldMessage[] = newMessage;

    public Main(){
        Spiel = new model_main(1500);
        try {
            server = new ServerSocket(port);
            for(int i = 0; i < sockenhaendler.length; i++){
                sockenhaendler[i] = new SocketHandlerThread(new SocketHandler(server.accept()));
                System.out.println("Client "+(i+1)+" connected");
            }
            server.close();
            // ab server.close sind alle Clients verbunden
        }catch(Exception e){e.printStackTrace();}
        brotkasten("sendnudes");
    }

    void brotkasten(String s){ // BROADCAST!
        for(int i = 0; i < sockenhaendler.length; i++){
            sockenhaendler[i].write(s);
        }
    }

    void hinrichtenNetzwerk(){
        for(int i = 0; i < sockenhaendler.length; i++){
            if ((newMessage[i] = sockenhaendler[i].read()) != oldMessage[i]){
                sockenhaendler[i].write(hendlNetzwerk(newMessage[i]));
                oldMessage[i] = newMessage[i];
            }
        }
    }

    String hendlNetzwerk(String message){
        return "";
    }
}